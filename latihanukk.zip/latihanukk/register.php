<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Register User</title>
  <style>
    body {
      font-family: Arial, sans-serif;
      background-color: #f4fcfa;
      margin: 0;
      padding: 0;
    }
    .navbar {
      background-color: white;
      padding: 15px 30px;
      box-shadow: 0 2px 4px rgba(0,0,0,0.1);
      display: flex;
      justify-content: space-between;
      align-items: center;
    }
    .navbar h1 {
      margin: 0;
      font-size: 20px;
      color: #007bff;
    }
    .register-container {
      max-width: 450px;
      margin: 50px auto;
      background: white;
      padding: 30px;
      border-radius: 10px;
      box-shadow: 0 0 10px rgba(0,0,0,0.1);
    }
    .register-container h2 {
      margin-bottom: 20px;
      color: #333;
    }
    .register-container label {
      display: block;
      margin-top: 10px;
      margin-bottom: 5px;
      font-weight: bold;
    }
    .register-container input,
    .register-container select {
      width: 100%;
      padding: 10px;
      font-size: 14px;
      margin-bottom: 15px;
      border-radius: 5px;
      border: 1px solid #ccc;
    }
    .register-container input[type="file"] {
      padding: 5px;
      border: 1px dashed #ccc;
      background-color: #f8f8f8;
    }
    .register-container button {
      background-color: #007bff;
      color: white;
      border: none;
      padding: 10px 20px;
      font-size: 16px;
      border-radius: 5px;
      cursor: pointer;
    }
    .footer {
      text-align: center;
      margin-top: 40px;
      padding: 10px;
      font-size: 14px;
      color: #666;
    }
  </style>
</head>
<body>
  <div class="navbar">
    <h1>Register User</h1>
    <a href="login.php">Home</a>
  </div>

  <div class="register-container">
    <h2>Form Registrasi</h2>
    <form action="proses_register.php" method="POST" enctype="multipart/form-data">
      <label for="username">Username</label>
      <input type="text" name="username" id="username" required>

      <label for="password">Password</label>
      <input type="password" name="password" id="password" required>

      <label for="foto">Foto</label>
      <input type="file" name="foto" id="foto" accept="image/*" required>

      <label for="status">Status</label>
      <select name="status" id="status" required>
        <option value="">-- Pilih --</option>
        <option value="siswa">Siswa</option>
        <option value="guru">Guru</option>
      </select>

      <button>
       <a href="user.php" class="btn-login">Register</a>
       </button>
    </form>
  </div>

  <div class="footer">
    © UKK Tahun Pelajaran 2024/2025
  </div>
</body>
</html>
