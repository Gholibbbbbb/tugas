

<?php
session_start();
include "koneksi.php";

// --- Simpan data jika form disubmit
if (isset($_POST['simpan'])) {
    $nama  = $_POST['nama'];
    $nis   = $_POST['nis'];
    $kelas = $_POST['kelas'];

    $query = "INSERT INTO siswa (nama, nis, kelas) VALUES ('$nama', '$nis', '$kelas')";
    $hasil = mysqli_query($koneksi, $query);

    if ($hasil) {
        echo "<script>alert('Data berhasil disimpan!'); window.location='siswa.php';</script>";
        exit;
    } else {
        echo "<script>alert('Gagal menyimpan data!');</script>";
    }
}

// --- Ambil semua data siswa
$data_siswa = mysqli_query($koneksi, "SELECT * FROM siswa");
?>

<!DOCTYPE html>
<html>
<head>
    <title>Data Siswa</title>
    <style>
        table { border-collapse: collapse; width: 60%; margin-top: 20px; }
        th, td { border: 1px solid #999; padding: 8px; text-align: center; }
        h2 { margin-bottom: 0; }
        form { margin-top: 20px; }
    </style>
</head>
<body>

<h2>Form Tambah Siswa</h2>
<form method="POST" action="">
    <label>Nama:</label><br>
    <input type="text" name="nama" required><br><br>

    <label>NIS:</label><br>
    <input type="text" name="nis" required><br><br>

    <label>Kelas:</label><br>
    <input type="text" name="kelas" required><br><br>

    <input type="submit" name="simpan" value="Simpan">
</form>

<hr>

<h2>Daftar Siswa</h2>
<table>
    <tr>
        <th>No</th>
        <th>Nama</th>
        <th>NIS</th>
        <th>Kelas</th>
    </tr>
    <?php
    $no = 1;
    while ($row = mysqli_fetch_assoc($data_siswa)) {
        echo "<tr>
                <td>{$no}</td>
                <td>{$row['nama']}</td>
                <td>{$row['nis']}</td>
                <td>{$row['kelas']}</td>
              </tr>";
        $no++;
    }
    ?>
</table>

</body>
</html>
