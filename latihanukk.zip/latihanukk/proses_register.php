<?php

session_start();
include "koneksi.php";

if (!$koneksi) {
    die("Koneksi gagal: " . mysqli_connect_error());
}

$username = $_POST['username'];
$password = password_hash($_POST['password'], PASSWORD_DEFAULT);
$status = $_POST['status'];

$foto = $_FILES['foto']['name'];
$tmp_foto = $_FILES['foto']['tmp_name'];
$folder = "uploads/";

if (!is_dir($folder)) {
    mkdir($folder, 0777, true);
}

move_uploaded_file($tmp_foto, $folder . $foto);

$sql = "INSERT INTO user (username, password, foto, status) VALUES ('$username', '$password', '$foto', '$status')";

if (mysqli_query($koneksi, $sql)) {
    echo "<script>alert('Registrasi berhasil!'); window.location='register.php';</script>";
} else {
    echo "Gagal: " . mysqli_error($koneksi);
}

mysqli_close($koneksi);
?>
