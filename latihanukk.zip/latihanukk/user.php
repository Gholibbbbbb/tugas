<!DOCTYPE html>
<html lang="id">
<head>
  <meta charset="UTF-8" />
  <meta name="viewport" content="width=device-width, initial-scale=1.0"/>
  <title>Login User</title>
  <style>
    * {
      margin: 0;
      padding: 0;
      box-sizing: border-box;
    }

    body {
      height: 100vh;
      background-color:hsl(105, 11.80%, 93.30%);
      display: flex;
      justify-content: center;
      align-items: center;
      font-family: Arial, sans-serif;
    }

    .login-card {
      background-color: white;
      padding: 40px 30px;
      border-radius: 40px;
      width: 100%;
      max-width: 600px;
      box-shadow: 0 10px 25px rgb(233, 109, 26);
      text-align: center;
    }

    .login-card img {
      width: 80px;
      margin-bottom: 15px;
    }

    .login-card h3 {
      color: #888;
      margin-bottom: 5px;
      font-weight: normal;
    }

    .login-card h2 {
      margin-bottom: 25px;
      color: #333;
    }

    .login-card input,
    .login-card select {
      width: 100%;
      padding: 12px;
      margin-bottom: 15px;
      border: 1px solid #ccc;
      border-radius: 8px;
      font-size: 14px;
    }

    .login-card button {
      width: 100%;
      padding: 12px;
      background-color:hsl(120, 65.40%, 50.20%);
      color: white;
      border: none;
      border-radius: 8px;
      font-size: 16px;
      cursor: pointer;
    }

    .login-card .register-link {
      margin-top: 15px;
      font-size: 14px;
    }

    .login-card .register-link a {
      color: #007bff;
      text-decoration: none;
    }

    .login-card .register-link a:hover {
      text-decoration: underline;
    }
  </style>
</head>
<body>

  <div class="login-card">
    <img src="RPL.jpg" alt="Logo">
    <h3>Mulai Akses Akun User</h3>
    <h2>Login User</h2>
    <form action="form_input.php" method="post">
      <input type="text" name="username" placeholder="Username" required>
      <input type="password" name="password" placeholder="Password" required>
      <select name="status" required>
        <option value="">-- Pilih Status --</option>
        <option value="siswa">Siswa</option>
        <option value="guru">Guru</option>
      </select>
      <button type="submit">Login</button>
    </form>
    <div class="register-link">
      Apakah Sudah Membuat Akun User? <a href="register.php">buat akun user</a>
    </div>
  </div>

</body>
</html>
