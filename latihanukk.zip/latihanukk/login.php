<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Website UKK 2025</title>
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 0;
            padding: 0;
            background-color: #f4f4f4;
        }
        header {
            background-color: white;
            padding: 20px;
            text-align: center;
            font-size: 28px;
            font-weight: bold;
            color: #1b3c59;
            box-shadow: 0 2px 4px rgba(0,0,0,0.1);
        }
        .btn-login {
            position: absolute;
            top: 20px;
            right: 20px;
            background-color: orange;
            color: white;
            border: none;
            padding: 10px 20px;
            border-radius: 5px;
            cursor: pointer;
            font-weight: bold;
        }
        .content {
            display: flex;
            padding: 40px;
            background-color: white;
        }
        .content img {
            width: 50%;
            border-radius: 8px;
        }
        .text {
            padding-left: 30px;
        }
        .text h2 {
            font-weight: bold;
        }
        .footer {
            text-align: center;
            padding: 20px;
            background-color: #1b3c59;
            color: white;
            position: relative;
        }
    </style>
</head>
<body>
    <header>
        WEBSITE UKK 2025
        <a href="register.php" class="btn-login">Login</a>
    </header>

    <div class="content">
        <img src="banner-02.jpg" alt="Foto RPL">
        <div class="text">
            <h2>REKAYASA PERANGKAT LUNAK</h2>
            <p><strong>VISI</strong><br>
            "menjadikan lulusan yang tangguh dalam teknologi informasi berkarakter dan siap menghadapi Globalisasi."</p>

            <p><strong>MISI</strong><br>
            1. Melaksanakan pengembangan dan implementasi kurikulum.<br>
            2. Menyiapkan sarana dan prasarana pembelajaran produktif dengan lengkap dan berkualitas.<br>
            3. Menjadikan insan yang kreatif, produktif dan inovatif dalam pengembangan.</p>

            <p><strong>KOMPETENSI KELAS XI KOMPUTER & INFORMATIKA</strong><br>
            1. Dapat merencanakan dan membuat kebutuhan basis data (Database)<br>
            2. Dapat membuat dan mendesain halaman web statis dan dinamis dengan bahasa program CSS, HTML, PHP, Javascript dsb.<br>
            3. Dapat membuat website secara native maupun menggunakan framework (CI atau Laravel).<br>
            4. Dapat membuat aplikasi berbasis desktop dengan menggunakan VB. Net.</p>
        </div>
    </div>

    <div class="footer">
        &copy; 2024-2025 UKK Jurusan Rekayasa Perangkat Lunak.
    </div>
</body>
</html>
