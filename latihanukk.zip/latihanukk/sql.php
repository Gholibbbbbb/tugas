CREATE TABLE tbl_siswa (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nis VARCHAR(12) NOT NULL UNIQUE,
    nomor_tes VARCHAR(12) NOT NULL UNIQUE,
    tanggal_tes DATE NOT NULL,
    bersedia_mengikuti_tes ENUM('bersedia', 'tidak bersedia') NOT NULL
);
