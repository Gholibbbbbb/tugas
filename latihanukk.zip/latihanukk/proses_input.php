<?php
session_start();
include "koneksi.php";

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

$nis = $_POST['nis'];
$nomor_tes = $_POST['nomor_tes'];
$tanggal_tes = $_POST['tanggal_tes'];
$bersedia = $_POST['bersedia_mengikuti_tes'];

$sql = "INSERT INTO tbl_siswa (nis, nomor_tes, tanggal_tes, bersedia_mengikuti_tes)
        VALUES (?, ?, ?, ?)";

$stmt = $koneksi->prepare($sql);
$stmt->bind_param("ssss", $nis, $nomor_tes, $tanggal_tes, $bersedia);

if ($stmt->execute()) {
    $_SESSION['sukses'] = "Data siswa berhasil disimpan!";
} else {
    $_SESSION['sukses'] = "Gagal menyimpan data: " . $stmt->error;
}

$stmt->close();
$koneksi->close();

header("Location: form_input.php");
exit;
