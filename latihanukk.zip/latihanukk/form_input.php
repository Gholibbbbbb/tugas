<?php
session_start();
include "koneksi.php";

if ($koneksi->connect_error) {
    die("Koneksi gagal: " . $koneksi->connect_error);
}

$pesan_sukses = '';
$pesan_error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['submit'])) {
    // Ambil input dan sanitasi
    $nis = htmlspecialchars($_POST['nis'] ?? '');
    $nomor_tes = htmlspecialchars($_POST['nomor_tes'] ?? '');
    $tanggal_tes = htmlspecialchars($_POST['tanggal_tes'] ?? '');
    $bersedia = htmlspecialchars($_POST['bersedia_mengikuti_tes'] ?? '');

    // Validasi input
    if ($nis && $nomor_tes && $tanggal_tes && $bersedia) {
        $sql = "INSERT INTO tbl_siswa (nis, nomor_tes, tanggal_tes, bersedia_mengikuti_tes) VALUES (?, ?, ?, ?)";
        $stmt = $koneksi->prepare($sql);

        if ($stmt) {
            $stmt->bind_param("ssss", $nis, $nomor_tes, $tanggal_tes, $bersedia);

            if ($stmt->execute()) {
                $pesan_sukses = "Data berhasil disimpan.";
            } else {
                $pesan_error = "Gagal menyimpan data: " . $stmt->error;
            }

            $stmt->close();
        } else {
            $pesan_error = "Prepare gagal: " . $koneksi->error;
        }
    } else {
        $pesan_error = "Semua kolom harus diisi.";
    }
}

$username = "Iqbal ghalib";
?>


<<!DOCTYPE html>
<html>
<head>
    <title>Form Input Data Siswa</title>
    <link rel="stylesheet" href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.0/css/bootstrap.min.css">
</head>
<body>
<div class="container mt-4">
    <div class="d-flex align-items-center mb-4">
        <img src="RPL.jpg" width="100" style="margin-right: 15px;">
        <h4>Selamat Datang, <?= $username ?> | 
            <a href="#" class="btn btn-primary">Logout</a>
        </h4>
    </div>

    <a href="siswa.php" class="btn btn-secondary mb-3">Data Tes</a>

    <h3>Form Input Data Siswa</h3>

    <?php if (!empty($pesan_sukses)): ?>
        <div class="alert alert-success"><?= $pesan_sukses ?></div>
    <?php elseif (!empty($pesan_error)): ?>
        <div class="alert alert-danger"><?= $pesan_error ?></div>
    <?php endif; ?>

    <form method="POST">
        <div class="card p-3 shadow-sm">
            <div class="form-group">
                <label for="nis">NIS:</label>
                <input type="text" name="nis" id="nis" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="nomor_tes">Nomor Tes:</label>
                <input type="text" name="nomor_tes" id="nomor_tes" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="tanggal_tes">Tanggal Tes:</label>
                <input type="date" name="tanggal_tes" id="tanggal_tes" class="form-control" required>
            </div>

            <div class="form-group">
                <label for="bersedia_mengikuti_tes">Bersedia Mengikuti Tes:</label>
                <select name="bersedia_mengikuti_tes" id="bersedia_mengikuti_tes" class="form-control" required>
                    <option value="">-- Pilih --</option>
                    <option value="bersedia">Bersedia</option>
                    <option value="tidak bersedia">Tidak Bersedia</option>
                </select>
            </div>

            <button type="submit" name="submit" class="btn btn-success">Simpan Data</button>
        </div>
    </form>
</div>
</body>
</html>
